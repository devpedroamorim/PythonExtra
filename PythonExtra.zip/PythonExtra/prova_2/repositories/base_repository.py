import mysql.connector

class BaseRepository:
    @staticmethod
    def _create_connection():
        conexao = mysql.connector.connect(host='localhost', user='root', password='1234', database='atv_extra1')
        return conexao
