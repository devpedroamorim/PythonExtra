import mysql.connector
from repositories.Repository import Repository

"""
    Classe ProdutoRepository para realizar operações no banco de dados relacionadas aos produtos.
    """
class ProdutoRepository(Repository):



        @staticmethod
        def create(nome, custo, categoria, estoque):
            """
                    Insere um novo produto no banco de dados.

                    Args:
                        nome (str): Nome do produto.
                        custo (float): Custo do produto.
                        categoria (str): Categoria do produto.
                        estoque (int): Quantidade em estoque do produto.
                    """

            conexao = ProdutoRepository.__criar_conexao()
            cursor = conexao.cursor()
            cursor.execute(f"INSERT INTO produto(nome, custo, categoria, estoque) VALUES ('{nome}',{custo},'{categoria}',{estoque});")
            conexao.commit()
            cursor.close()
            conexao.close()

        @staticmethod
        def _read():
            """
                    Busca todos os produtos do banco de dados.

                    Returns:
                        list: Lista de produtos encontrados no banco de dados.
                    """

            conexao = ProdutoRepository.__criar_conexao()
            cursor = conexao.cursor()
            comando = 'SELECT * FROM produto;'
            cursor.execute(comando)
            produtosBanco = cursor.fetchall()
            return produtosBanco
            cursor.close()
            conexao.close()

        @staticmethod
        def update(produto_id, nome, custo, categoria, estoque):
            """
                    Atualiza um produto existente no banco de dados.

                    Args:
                        produto_id (int): ID do produto a ser atualizado.
                        nome (str): Nome atualizado do produto.
                        custo (float): Custo atualizado do produto.
                        categoria (str): Categoria atualizada do produto.
                        estoque (int): Quantidade atualizada em estoque do produto.
                    """

            conexao = ProdutoRepository.__criar_conexao()
            cursor = conexao.cursor()
            cursor.execute(
                f"UPDATE produto SET nome='{nome}', custo={custo}, categoria='{categoria}', estoque={estoque} WHERE produtoID = {produto_id};")
            conexao.commit()
            cursor.close()
            conexao.close()

        @staticmethod
        def delete(escolha):
            """
                    Exclui um produto do banco de dados com base no ID fornecido.

                    Args:
                        escolha (int): ID do produto a ser excluído.
                    """

            conexao = ProdutoRepository.__criar_conexao()
            cursor = conexao.cursor()
            cursor.execute(
                f"delete FROM produto WHERE produtoID = {escolha}")
            conexao.commit()
            cursor.close()
            conexao.close()

        @staticmethod
        def __criar_conexao():
            """
                    Cria e retorna uma conexão com o banco de dados.

                    Returns:
                        mysql.connector.connection: Conexão com o banco de dados.
                    """
            conexao = mysql.connector.connect(host='localhost', user='root', password='1234', database='atv_extra1')
            return conexao
