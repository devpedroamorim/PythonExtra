import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from repositories.ProdutoRepository import ProdutoRepository

class ProdutoController:
    """
    Classe ProdutoController para criar uma interface gráfica para gerenciar produtos.
        """
    @staticmethod
    def exibir_menu():
        """
        Exibe o menu principal da aplicação, permitindo ao usuário escolher entre diferentes ações.
                """

        window = tk.Tk()
        largura_janela_root = 800
        altura_janela_root = 400

        largura_tela_root = window.winfo_screenwidth()
        altura_tela_root = window.winfo_screenheight()

        pos_x_root = int(largura_tela_root / 2 - largura_janela_root / 2)
        pos_y_root = int(altura_tela_root / 2 - altura_janela_root / 2)

        window.geometry(f"{largura_janela_root}x{altura_janela_root}+{pos_x_root}+{pos_y_root}")
        window.configure(bg="#000000")
        window.title("Gerenciador de Produtos")

        # Criação da janela principal

        # Funções para cada ação do menu
        def cadastrar_produtos():
            """
            Cria e exibe uma janela para cadastrar um novo produto.
                        """

            window2 = tk.Tk()
            window2.title("Cadastro de Produto")
            form_frame = tk.Frame(window2)
            form_frame.pack(padx=10, pady=10)

            def cadastrar_produto(nome_entry, custo_entry, categoria_entry, estoque_entry):
                try:
                    nome = nome_entry.get()
                    custo = float(custo_entry.get())
                    categoria = categoria_entry.get()
                    estoque = int(estoque_entry.get())

                    ProdutoRepository.create(nome, custo, categoria, estoque)
                    messagebox.showinfo("Sucesso", "Produto cadastrado com sucesso!")


                except ValueError as e:
                    messagebox.showerror("Erro", f"Erro: {str(e)}")
                except Exception as e:
                    messagebox.showerror("Erro", f"Mensagem de Erro: {str(e)}")

            nome_label = tk.Label(form_frame, text="Nome do produto:")
            nome_label.grid(row=0, column=0, sticky="e", pady=(0, 5))
            nome_entry = tk.Entry(form_frame)
            nome_entry.grid(row=0, column=1, pady=(0, 5))

            custo_label = tk.Label(form_frame, text="Custo do produto:")
            custo_label.grid(row=1, column=0, sticky="e", pady=(0, 5))
            custo_entry = tk.Entry(form_frame)
            custo_entry.grid(row=1, column=1, pady=(0, 5))

            categoria_label = tk.Label(form_frame, text="Categoria do produto:")
            categoria_label.grid(row=2, column=0, sticky="e", pady=(0, 5))
            categoria_entry = tk.Entry(form_frame)
            categoria_entry.grid(row=2, column=1, pady=(0, 5))

            estoque_label = tk.Label(form_frame, text="Quantidade em estoque:")
            estoque_label.grid(row=3, column=0, sticky="e", pady=(0, 5))
            estoque_entry = tk.Entry(form_frame)
            estoque_entry.grid(row=3, column=1, pady=(0, 5))

            cadastrar_button = tk.Button(form_frame, text="Cadastrar", command=lambda: cadastrar_produto(nome_entry, custo_entry, categoria_entry, estoque_entry))
            cadastrar_button.grid(row=4, columnspan=2, pady=10)

            return nome_entry, custo_entry, categoria_entry, estoque_entry

            window2.mainloop()

        def listar_produtos():

            """
            Cria e exibe uma janela com uma tabela listando todos os produtos cadastrados.
                        """

            def exibir_produtos():
                produtos = ProdutoRepository._read()
                if not produtos:
                    print("Não há produtos cadastrados.")
                else:
                    for indice, nome, custo, categoria, estoque in (produtos):
                        tabela.insert('', 'end', values=(indice, nome, f"{custo:.2f}", categoria, estoque))

            def criar_tabela(window3):
                tabela = ttk.Treeview(window3, columns=("indice", "nome", "custo", "categoria", "estoque"),
                                      show="headings")

                tabela.heading("indice", text="ID")
                tabela.heading("nome", text="Nome")
                tabela.heading("custo", text="Preço")
                tabela.heading("categoria", text="Categoria")
                tabela.heading("estoque", text="Quantidade em estoque")

                tabela.column("indice", anchor=tk.CENTER, width=50)
                tabela.column("nome", anchor=tk.W, width=200)
                tabela.column("custo", anchor=tk.CENTER, width=100)
                tabela.column("categoria", anchor=tk.W, width=150)
                tabela.column("estoque", anchor=tk.CENTER, width=150)

                tabela.pack(fill=tk.BOTH, expand=True)

                return tabela

            window3 = tk.Tk()
            window3.title("Produtos cadastrados")

            tabela = criar_tabela(window3)
            exibir_produtos()

            window3.mainloop()

        def excluir_produtos():
            """
            Cria e exibe uma janela para excluir um produto com base no ID fornecido.
                        """

            def excluir_produto():
                try:
                    escolha = int(entry_id.get())
                    ProdutoRepository.delete(escolha)
                    messagebox.showinfo("Sucesso", "Produto excluído com sucesso.")
                    exibir_produtos()
                except ValueError as e:
                    messagebox.showerror("Erro", f"Erro: {str(e)}")
                except Exception as e:
                    messagebox.showerror("Erro", f"Mensagem de Erro: {str(e)}")

            def exibir_produtos():
                produtos_banco = ProdutoRepository._read()
                lista_produtos.delete(0, tk.END)
                for i in produtos_banco:
                    lista_produtos.insert(tk.END, f"{i[0]}: {i[1]}")

            window5 = tk.Tk()
            window5.title("Excluir Produto")

            frame_entrada = tk.Frame(window5)
            frame_entrada.pack(pady=10)

            label_id = tk.Label(frame_entrada, text="Digite o ID do Produto que deseja excluir:")
            label_id.pack(side=tk.LEFT, padx=(0, 10))

            entry_id = tk.Entry(frame_entrada)
            entry_id.pack(side=tk.LEFT)

            frame_botoes = tk.Frame(window5)
            frame_botoes.pack(pady=10)

            botao_excluir = tk.Button(frame_botoes, text="Excluir", command=excluir_produto)
            botao_excluir.pack(side=tk.LEFT, padx=(0, 10))

            lista_produtos = tk.Listbox(window5, width=50, height=10)
            lista_produtos.pack(pady=10)

            exibir_produtos()

            window5.mainloop()

        # Função para criar o menu principal
        def create_menu():
            """
            Cria o menu principal com botões para cada ação.
                        """

            main_frame = tk.Frame(window)
            main_frame.pack(padx=10, pady=10, expand=True)

            title_label = tk.Label(main_frame, text="Menu", font=("Arial", 16))
            title_label.pack(pady=5)

            cadastrar_button = tk.Button(main_frame, text="Cadastrar Produto", command=cadastrar_produtos)
            cadastrar_button.pack(pady=5)

            listar_button = tk.Button(main_frame, text="Listar Produtos", command=listar_produtos)
            listar_button.pack(pady=5)

            excluir_button = tk.Button(main_frame, text="Excluir Produto", command=excluir_produtos)
            excluir_button.pack(pady=5)

            sair_button = tk.Button(main_frame, text="Sair", command=window.destroy)
            sair_button.pack(pady=5)

        create_menu()
        window.mainloop()

