class Produto:

    def __init__(self, nome, custo, categoria, estoque=0):

        self._nome = nome
        self._custo = custo
        self._categoria = categoria
        self._estoque = estoque

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, produto_nome):
        if produto_nome.strip() == "":
            raise ValueError('Nome do produto inválido')
        self._nome = produto_nome.upper()

    @property
    def custo(self):
        return self._custo

    @custo.setter
    def custo(self, produto_custo):
        if produto_custo < 0:
            raise ValueError('Custo inválido')
        self._custo = produto_custo

    @property
    def categoria(self):
        return self._categoria

    @categoria.setter
    def categoria(self, produto_categoria):
        if produto_categoria.strip() == "":
            raise ValueError('Nome da categoria inválido')
        self._categoria = produto_categoria.upper()

    def consultar_estoque(self):
        return self._estoque

    def alterar_estoque(self, quantidade):
        if quantidade < 0 and abs(quantidade) > self._estoque:
            raise ValueError("Quantidade inválida")
        self._estoque += quantidade

    def __str__(self):
        return f"Nome: {self.nome} | Preço: {self.custo:.2f} | Categoria: {self.categoria} | Quantidade em estoque: {self.consultar_estoque()}"

